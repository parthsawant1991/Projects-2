import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class Problem3Process2 {

	public static int balance = 1000;

	/*
	 * the synchronized get method ensures that concurrent access to the
	 * variable does not take place
	 */
	synchronized static int getBalance() {
		return Problem3Process2.balance;
	}

	/*
	 * the synchronized set method ensures that concurrent access to the
	 * variable does not take place
	 */
	synchronized static void setBalance(int bal) {
		Problem3Process2.balance = bal;
	}

	public static String sendserver1 = "localhost"; // server name of process 1
	public static String sendserver3 = "localhost"; // server name of process 3

	public static int sendport1 = 11000; // channel to send money to process 1
	public static int sendport3 = 14000; // channel to send money to process 3
	public static int receiveport1 = 10000; // channel to receive money from
											// process 1
	public static int receiveport3 = 15000; // channel to receive money from
											// process 3

	public static int receivechannel1 = 20000; // channel to receive state from
												// process
	// 1
	public static int receivechannel3; // channel to receive state from process
										// 3
	public static int sendchannelport1 = 21000; // channel to send marker to
												// process 1
	public static int sendchannelport3; // channel to send marker to process 3

	public static int channel1balance = 0; // amount that is on the channel
											// before receiving back the marker
	public static int channel3balance = 0; // amount that is on the channel
											// before receiving back the marker

	public static boolean blockchannel1 = false; // whether waiting for a marker
	public static boolean blockchannel3 = false; // whether waiting for a marker

	public static void main(String[] args) throws InterruptedException, IOException {

		System.out.println("starting all receiver channel threads");

		/*
		 * threads to receive money
		 */
		new Thread(new P2R1()).start();
		new Thread(new P2R3()).start();

		/*
		 * threads to receive markers and states
		 */
		new Thread(new P2RC1()).start();
		// new Thread(new P2RC3()).start();

		/*
		 * thread to start markers
		 */
		// new Thread(new P2Mk()).start();

		int count = 10;

		/*
		 * starting transaction loop
		 */

		Thread.sleep(4000);

		while (count > 0) {

			Thread.sleep(1000);

			int randomserver = (int) (Math.random() * 1000 % 2);

			int randomamount = (int) (Math.random() * 1000 % 100);

			System.out.println("Send to " + randomserver + " " + randomamount);

			int bal = Problem3Process2.getBalance();
			bal -= randomamount;
			Problem3Process2.setBalance(bal);

			if (randomserver == 0) {

				Socket clientsocket = new Socket(Problem3Process2.sendserver1, Problem3Process2.sendport1);

				if (clientsocket.isConnected()) {

					PrintWriter clientout = new PrintWriter(clientsocket.getOutputStream(), true);

					clientout.println(randomamount);
					clientout.flush();
					clientout.close();

				}
				clientsocket.close();

			}

			else if (randomserver == 1) {

				Socket clientsocket = new Socket(Problem3Process2.sendserver3, Problem3Process2.sendport3);

				if (clientsocket.isConnected()) {

					PrintWriter clientout = new PrintWriter(clientsocket.getOutputStream(), true);

					clientout.println(randomamount);
					clientout.flush();
					clientout.close();

				}
				clientsocket.close();

			}

			count--;

		}

	

	}

}

class P2R1 implements Runnable {

	public P2R1() {

	}

	@Override
	public void run() {

		try {

			/*
			 * this is listening for any incoming communication to receive money
			 */
			while (true) {

				ServerSocket receivesocket = null;

				Socket receive = null;

				receivesocket = new ServerSocket(Problem3Process2.receiveport1);

				receive = receivesocket.accept();

				BufferedReader br = new BufferedReader(new InputStreamReader(receive.getInputStream()));

				int incomingBal = Integer.parseInt(br.readLine());
				//
				// System.out.println("Incoming balance " + incomingBal);
				//
				// System.out.println("Current Balance " +
				// (Problem3Process2.balance + incomingBal));

				int bal = Problem3Process2.getBalance();
				bal += incomingBal;
				Problem3Process2.setBalance(bal);

				receive.close();

				receivesocket.close();

			}

		} catch (IOException e) {
			e.printStackTrace();
		}

	}
}

class P2R3 implements Runnable {

	public P2R3() {

	}

	@Override
	public void run() {

		try {

			/*
			 * this is listening for any incoming communication to receive money
			 */
			while (true) {

				ServerSocket receivesocket = null;

				Socket receive = null;

				receivesocket = new ServerSocket(Problem3Process2.receiveport3);

				receive = receivesocket.accept();

				BufferedReader br = new BufferedReader(new InputStreamReader(receive.getInputStream()));

				int incomingBal = Integer.parseInt(br.readLine());

				// System.out.println("Incoming balance " + incomingBal);
				//
				// System.out.println("Current Balance " +
				// (Problem3Process2.balance + incomingBal));

				int bal = Problem3Process2.getBalance();
				bal += incomingBal;
				Problem3Process2.setBalance(bal);

				receive.close();

				receivesocket.close();

			}

		} catch (IOException e) {
			e.printStackTrace();
		}

	}
}

/*
 * this class is the thread implementation of the incoming channel marker
 * receiver, to receive and record the state of the processes
 */
class P2RC1 implements Runnable {

	public P2RC1() {

	}

	@Override
	public void run() {

		try {

			/*
			 * this is listening for any incoming communication to receive state
			 * of the process
			 */
			while (true) {

				ServerSocket receivesocket = null;

				Socket receive = null;

				receivesocket = new ServerSocket(Problem3Process2.receivechannel1);

				receive = receivesocket.accept();

				BufferedReader br = new BufferedReader(new InputStreamReader(receive.getInputStream()));

				String incomingState = br.readLine();

				System.out.println("Process 1: " + incomingState);

				// Problem3Process2.blockchannel1 = false;

				receive.close();

				receivesocket.close();

				/*
				 * send state to process 1
				 */

				Socket clientsocket1 = new Socket(Problem3Process2.sendserver1, Problem3Process2.sendchannelport1);

				if (clientsocket1.isConnected()) {

					PrintWriter clientout1 = new PrintWriter(clientsocket1.getOutputStream(), true);

					clientout1.println(Problem3Process2.balance + " " + Problem3Process2.channel1balance + " "
							+ Problem3Process2.channel3balance);
					clientout1.flush();
					clientout1.close();

				}
				clientsocket1.close();

			}

		} catch (IOException e) {
			e.printStackTrace();
		}

	}
}

/*
 * this class is the thread implementation of the incoming channel marker
 * receiver, to receive and record the state of the processes
 */
class P2RC3 implements Runnable {

	public P2RC3() {

	}

	@Override
	public void run() {

		try {

			/*
			 * this is listening for any incoming communication to receive state
			 * of the process
			 */
			while (true) {

				ServerSocket receivesocket = null;

				Socket receive = null;

				receivesocket = new ServerSocket(Problem3Process2.receivechannel1);

				receive = receivesocket.accept();

				BufferedReader br = new BufferedReader(new InputStreamReader(receive.getInputStream()));

				int incomingState = Integer.parseInt(br.readLine());

				System.out.println("Process 3: " + incomingState);

				// Problem3Process2.blockchannel1 = false;

				receive.close();

				receivesocket.close();

				/*
				 * 
				 * send state to process 1
				 */

				Socket clientsocket1 = new Socket(Problem3Process2.sendserver3, Problem3Process2.sendchannelport3);

				if (clientsocket1.isConnected()) {

					PrintWriter clientout1 = new PrintWriter(clientsocket1.getOutputStream(), true);

					clientout1.println("Problem3Process2.balance " + Problem3Process2.channel1balance + " "
							+ Problem3Process2.channel3balance);
					clientout1.flush();
					clientout1.close();

				}
				clientsocket1.close();

			}

		} catch (IOException e) {
			e.printStackTrace();
		}

	}
}

/*
 * this class contains the implementation of marker generation and transmission
 * of markers
 */
class P2Mk implements Runnable {

	@Override
	public void run() {

		int count = 20;
		try {
			while (count > 0) {

				Thread.sleep(2000);

				// send marker to process 1

				Socket clientsocket1 = new Socket(Problem3Process2.sendserver1, Problem3Process2.sendchannelport1);

				if (clientsocket1.isConnected()) {

					PrintWriter clientout1 = new PrintWriter(clientsocket1.getOutputStream(), true);

					clientout1.println("marker from 2");
					clientout1.flush();
					clientout1.close();

				}
				clientsocket1.close();

				Problem3Process2.blockchannel1 = true;

				// send marker to process 3

				Socket clientsocket3 = new Socket(Problem3Process2.sendserver3, Problem3Process2.sendchannelport3);

				if (clientsocket3.isConnected()) {

					PrintWriter clientout3 = new PrintWriter(clientsocket3.getOutputStream(), true);

					clientout3.println("marker from 2");
					clientout3.flush();
					clientout3.close();

				}
				clientsocket3.close();

				Problem3Process2.blockchannel3 = true;

			}

		} catch (InterruptedException | IOException e) {
			e.printStackTrace();
		}

	}

}
