import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/**
 * This class contains the implementation of a 1D classifier.
 * 
 * @author Parth Sawant pss7278
 *
 */
public class HW03_Sawant_Parth_program {

	/*
	 * this method is the main thread of execution for the classification
	 * program
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// reading csv file
		System.out.println("CLASSIFIED_TRAINING_SET_FOR_RECKLESS_DRIVERS_2016:");
		String csv_file = "CLASSIFIED_TRAINING_SET_FOR_RECKLESS_DRIVERS_2016.csv";
		BufferedReader br = null;
		String line = "";
		String csv_split = ",";
		String[] speed = null;
		Double[] speeds = new Double[128];
		int[] reck = new int[128];
		double min = 100;
		double max = 0;
		int true_non_reck = 0;
		int true_reck = 0;

		int k = -1;

		try {

			br = new BufferedReader(new FileReader(csv_file));

			/*
			 * reading the csv file
			 */
			while ((line = br.readLine()) != null) {

				// use comma as separator
				speed = line.split(csv_split);

				if (speed[0].length() < 5) {

					speeds[++k] = Double.parseDouble(speed[0]);

					double raw = Double.parseDouble(speed[0]);
					int raw_int = Integer.parseInt(speed[0].substring(0, 2));

					/*
					 * quantizing the values to the nearest 0.5
					 */
					if (raw - raw_int < 0.25) {
						speeds[k] = (double) raw_int;
					} else if (raw - raw_int < 0.5) {
						speeds[k] = (double) raw_int + 0.5;
					} else if (raw - raw_int < 0.75) {
						speeds[k] = (double) raw_int + 0.5;
					} else {
						speeds[k] = (double) raw_int + 1;
					}

					reck[k] = Integer.parseInt(speed[1]);

					if (reck[k] == 0) {
						true_non_reck++;
					} else if (reck[k] == 1) {
						true_reck++;
					}

					if (speeds[k] < min) {
						min = speeds[k];
					}
					if (speeds[k] > max) {
						max = speeds[k];
					}

				}
				// System.out.println(speed[0]);

			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

		// for (int i = 0; i < speeds.length; i++) {
		// System.out.println(speeds[i] + " " + reck[i]);
		// }

		System.out.println("Minimum speed: " + min);

		System.out.println("Maximum speed: " + max);

		int[] true_positive = new int[(int) ((max - min) * 2) + 1];
		int[] true_negative = new int[(int) ((max - min) * 2) + 1];

		int[] false_positive = new int[(int) ((max - min) * 2) + 1];
		int[] false_negative = new int[(int) ((max - min) * 2) + 1];

		double threshold = min;

		int counter = 0;

		/*
		 * computing the true neg/pos, false neg/pos for all values of threshold
		 */
		while (threshold <= max) {

			for (int i = 0; i < speeds.length; i++) {

				if (speeds[i] <= threshold && reck[i] == 0) {
					true_negative[counter]++;
				} else if (speeds[i] <= threshold && reck[i] == 1) {
					false_negative[counter]++;
				} else if (speeds[i] > threshold && reck[i] == 0) {
					false_positive[counter]++;
				} else if (speeds[i] > threshold && reck[i] == 1) {
					true_positive[counter]++;
				}

			}
			counter++;
			threshold += 0.5;

		}

		threshold = min;
		double best_threshold = 0;
		double miss_classification = 128;

		for (int i = 0; i < true_positive.length; i++) {

			// System.out.println("Threshold: " + threshold + " TP: " +
			// true_positive[i] + " TN: " + true_negative[i]
			// + " FP: " + false_positive[i] + " FN: " + false_negative[i]);

			// System.out.println(false_positive[i]/(double)true_non_reck+", "
			// );

			/*
			 * computing the best threshold depending on the number miss
			 * classifications
			 */
			if (false_positive[i] + false_negative[i] <= miss_classification) {
				miss_classification = false_negative[i] + false_positive[i];
				best_threshold = threshold;
			}

			threshold += 0.5;
		}

		System.out.println("Best Threshold (exclusive): " + best_threshold + " with a misclassification rate of "
				+ miss_classification + "/" + "128.0 = " + (miss_classification / 128));

		/*
		 * reading csv file to classify
		 */
		System.out.println("SPEEDS_TO_CLASSIFY_2016 (2): ");
		String csvFile1 = "SPEEDS_TO_CLASSIFY_2016 (2).csv";
		BufferedReader br1 = null;
		String line1 = "";
		String cvsSplitBy1 = ",";
		String[] speed1 = null;
		Double[] speeds1 = new Double[10];
		int[] reck1 = new int[10];
		double min1 = 100;
		double max1 = 0;

		int k1 = -1;

		/*
		 * reading the csv file for classification
		 */
		try {

			br1 = new BufferedReader(new FileReader(csvFile1));

			while ((line1 = br1.readLine()) != null) {

				// use comma as separator
				speed1 = line1.split(cvsSplitBy1);

				if (speed1[0].length() < 5) {

					speeds1[++k1] = Double.parseDouble(speed1[0]);

					double raw1 = Double.parseDouble(speed1[0]);
					int raw_int1 = Integer.parseInt(speed1[0].substring(0, 2));

					// if (raw1 - raw_int1 < 0.25) {
					// speeds1[k1] = (double) raw_int1;
					// } else if (raw1 - raw_int1 < 0.5) {
					// speeds1[k1] = (double) raw_int1 + 0.5;
					// } else if (raw1 - raw_int1 < 0.75) {
					// speeds1[k1] = (double) raw_int1 + 0.5;
					// } else {
					// speeds1[k1] = (double) raw_int1 + 1;
					// }

					// reck1[k1] = Integer.parseInt(speed1[1]);

					/*
					 * computes the minimum and maximum speed in the given
					 * dataset.
					 */
					if (speeds1[k1] < min1) {
						min1 = speeds1[k1];
					}
					if (speeds1[k1] > max1) {
						max1 = speeds1[k1];
					}

					/*
					 * classifies the driver as reckless/not depending on the
					 * threshold obtained from the training data.
					 */
					if (speeds1[k1] <= best_threshold) {
						reck1[k1] = 0;
					} else {
						reck1[k1] = 1;
					}

				}
				// System.out.println(speed[0]);

			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

		for (int i = 0; i < speeds1.length; i++) {
			System.out.println(speeds1[i] + " " + reck1[i]);
		}

		System.out.println("Minimum speed: " + min1);

		System.out.println("Maximum speed: " + max1);

		makeCSV("HW_03_Sawant_Parth_CLASSIFICATIONS.csv", speeds1, reck1);

	}

	/**
	 * \ This method is used to write the csv file.
	 * 
	 * @param filename
	 *            name of the csv file
	 * @param speeds1
	 *            first column values of the csv file
	 * @param reck1
	 *            second column values of the csv file
	 */
	private static void makeCSV(String filename, Double[] speeds1, int[] reck1) {
		try {
			FileWriter fwriter = new FileWriter(filename);

			for (int i = 0; i < speeds1.length; i++) {
				fwriter.append(Double.toString(speeds1[i]));
				fwriter.append(',');
				fwriter.append(Integer.toString(reck1[i]));
				fwriter.append('\n');
			}

			fwriter.flush();
			fwriter.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
