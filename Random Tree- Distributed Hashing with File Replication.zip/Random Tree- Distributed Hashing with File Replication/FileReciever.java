import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;

public class FileReciever implements Runnable {

	int fileport;

	public FileReciever(int fileport) {
		this.fileport = fileport;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub

		ServerSocket fileserv = null;
		ServerSocket serv = null;
		try {
			serv = new ServerSocket(fileport);
			fileserv = new ServerSocket(fileport + 10);
			Socket s = null;
			Socket fs = null;
			s = serv.accept();

			BufferedReader br;

			br = new BufferedReader(new InputStreamReader(s.getInputStream()));

			String filename = br.readLine();

			s.close();

			if (Server.filedirectory.containsKey(filename)) {

			} else {
				Server.filedirectory.put(filename, 0);
			}
			fs = fileserv.accept();

			byte[] mybytearray = new byte[1024];
			InputStream is = s.getInputStream();
			FileOutputStream fos = new FileOutputStream(filename);
			BufferedOutputStream bos = new BufferedOutputStream(fos);
			int bytesRead = is.read(mybytearray, 0, mybytearray.length);
			bos.write(mybytearray, 0, bytesRead);
			bos.flush();
			bos.close();
			s.close();
			serv.close();
		} catch (Exception e) {

		}

	}

}
