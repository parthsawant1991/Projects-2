import java.awt.FileDialog;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketAddress;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.Scanner;

public class Server implements Runnable {

	static HashMap<String, Integer> filedirectory = new HashMap<String, Integer>();

	Socket sock;

	public Server(Socket sock) {
		this.sock = sock;
	}

	@SuppressWarnings("resource")
	public static void main(String[] args) throws UnknownHostException, IOException {

		// serverID = Integer.parseInt(args[0]);
		 filedirectory.put("ABC.txt", 0);
//		 filedirectory.put("DEF.txt", 0);
		Scanner sc = new Scanner(System.in);
		System.out.println("Starting Server: ");
		System.out.println("Enter Server Port:");
		int port = sc.nextInt();
		int fileport = port + 5;
		ServerSocket serv = null;

		serv = new ServerSocket(port);

		while (true) {

			Socket s = null;
			s = serv.accept();
			new Thread(new Server(s)).start();

			new Thread(new FileReciever(fileport)).start();

		}

	}

	@Override
	public void run() {
		// TODO Auto-generated method stub

		BufferedReader br;
		try {
			br = new BufferedReader(new InputStreamReader(sock.getInputStream()));

			String filename = br.readLine();
			String clientname = br.readLine();
			int clientport = Integer.parseInt(br.readLine());
			int i = Integer.parseInt(br.readLine());
			int j = Integer.parseInt(br.readLine());
			boolean isClient = Boolean.parseBoolean(br.readLine());

			sock.close();

			if (filedirectory.containsKey(filename)) {
				int count = filedirectory.get(filename);
				count++;

				if (count == 5) {

					System.out.println("Replicate");
					replicateToChildren(filename, i, j);
				}
				filedirectory.put(filename, count);
				System.out.println("File: " + filename + " count: " + filedirectory.get(filename));
				sendFile(filename, clientname, clientport);

			} else {

				System.out.println("Escalating request to parent");
				escalateRequest(filename, clientname, clientport, i, j);

			}

		} catch (Exception e) {

		}

	}

	private void replicateToChildren(String filename, int i, int j) throws UnknownHostException, IOException {
		// TODO Auto-generated method stub

		int rootid = getServerIP(filename, 0, 0);
		int child1 = 0, child2 = 0;

		if (i == 1) {
			child1 = getServerIP(filename, 1, 0);
			child2 = getServerIP(filename, 1, 1);
			System.out.println("Replicating to " + child1 + " " + child2);

		} else if (i == 2) {
			if (j < 2) {
				child1 = getServerIP(filename, 2, 0);

				child2 = getServerIP(filename, 2, 1);
				System.out.println("Replicating to " + child1 + " " + child2);

			} else {
				child1 = getServerIP(filename, 2, 2);
				child2 = getServerIP(filename, 1, 3);
				System.out.println("Replicating to " + child1 + " " + child2);

			}

		}

		// sending to child 1
		Socket client_socket1 = new Socket("localhost", child1);

		if (client_socket1.isConnected()) {

			byte[] mybytearray1 = new byte[1024];
			BufferedInputStream bis = new BufferedInputStream(new FileInputStream(filename));
			bis.read(mybytearray1, 0, mybytearray1.length);
			OutputStream os = client_socket1.getOutputStream();
			os.write(mybytearray1, 0, mybytearray1.length);
			os.flush();
			client_socket1.close();
			client_socket1 = null;
		}

		// sending to child 2
		Socket client_socket2 = new Socket("localhost", child2);

		if (client_socket2.isConnected()) {

			byte[] mybytearray12 = new byte[1024];
			BufferedInputStream bis1 = new BufferedInputStream(new FileInputStream(filename));
			bis1.read(mybytearray12, 0, mybytearray12.length);
			OutputStream os1 = client_socket2.getOutputStream();
			os1.write(mybytearray12, 0, mybytearray12.length);
			os1.flush();
			client_socket2.close();
			client_socket2 = null;
		}

	}

	private void escalateRequest(String filename, String clientname, int clientport, int i, int j) throws IOException {
		// TODO Auto-generated method stub

		int rootip = getServerIP(filename, 0, 0);
		int parenti, parentj;

		parenti = i - 1;
		if (j > 2) {
			parentj = 1;
		} else {
			parentj = 0;
		}

		int serverport = getServerIP(filename, parenti, parentj);

		Socket client_socket = new Socket("localhost", serverport);

		if (client_socket.isConnected()) {

			System.out.println("TCP Client connected to " + client_socket.getInetAddress() +

			" on port " + client_socket.getPort());

			PrintWriter clout = new PrintWriter(client_socket.getOutputStream(), true);

			clout.println(filename);
			clout.println(client_socket.getLocalAddress().getHostName());
			clout.println((client_socket.getLocalPort() + 1));
			clout.println(i);
			clout.println(j);
			clout.println("false");
			clout.flush();
			client_socket.close();

		}

	}

	static int getServerIP(String filename, int i, int j) {

		HashMap<Integer, Integer> servermap = new HashMap<Integer, Integer>();

		servermap.put(0, 10100);
		servermap.put(1, 10200);
		servermap.put(2, 10300);
		servermap.put(3, 10400);
		servermap.put(4, 10500);
		servermap.put(5, 10600);
		servermap.put(6, 10700);

		int rootindex = Math.abs((filename.hashCode()) % 7);

		// System.out.println(filename.hashCode() + " " + rootindex);

		if (i == 0) {
			return servermap.get(rootindex);
		} else if (i == 1) {

			if (j == 0) {
				return servermap.get((rootindex + 1) % 7);
			} else {
				return servermap.get((rootindex + 2) % 7);
			}

		}

		else {

			return servermap.get((rootindex + 3 + j) % 7);

		}

	}

	private void sendFile(String filename, String clientname, int clientport) throws Exception {
		// TODO Auto-generated method stub

		Socket client_socket = new Socket(clientname, clientport);

		if (client_socket.isConnected()) {

			byte[] mybytearray1 = new byte[1024];
			BufferedInputStream bis = new BufferedInputStream(new FileInputStream(filename));
			bis.read(mybytearray1, 0, mybytearray1.length);
			OutputStream os = client_socket.getOutputStream();
			os.write(mybytearray1, 0, mybytearray1.length);
			os.flush();
			client_socket.close();
			client_socket = null;

			// PrintWriter client_out = new
			// PrintWriter(client_socket.getOutputStream(), true);
			//
			// client_out.println("File Found");
			// client_out.flush();
			// client_socket.close();

		}

	}

}
