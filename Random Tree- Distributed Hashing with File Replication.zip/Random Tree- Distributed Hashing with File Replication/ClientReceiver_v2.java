import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class ClientReceiver_v2 implements Runnable {

	Socket filesocket;
	String filename;

	public ClientReceiver_v2(Socket sock, String filename) {
		this.filesocket = sock;
		this.filename = filename;

	}

	@Override
	public void run() {
		// TODO Auto-generated method stub

		byte[] mybytearray = new byte[1024];
		InputStream is;
		try {
			is = filesocket.getInputStream();

			FileOutputStream fos;

			fos = new FileOutputStream("TABC.txt");

			BufferedOutputStream bos = new BufferedOutputStream(fos);
			int bytesRead = is.read(mybytearray, 0, mybytearray.length);
			bos.write(mybytearray, 0, bytesRead);
			bos.flush();
			bos.close();
			filesocket.close();
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return;

	}

}
