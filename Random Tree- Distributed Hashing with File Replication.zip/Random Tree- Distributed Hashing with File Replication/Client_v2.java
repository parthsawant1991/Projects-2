import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.Scanner;

public class Client_v2 {

	@SuppressWarnings("resource")
	public static void main(String[] args) throws UnknownHostException, IOException {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);

		System.out.println("Enter file name");
		String fname = sc.next();

		System.out.println("1. Insert File:");
		System.out.println("2. Retrieve File:");
		int option = sc.nextInt();
		int listenport = 0;

		if (option == 1) {

			insertFile(fname);

		} else if (option == 2) {

			int serverport = getServerIP(fname, 2, Math.abs((int) Math.random() % 4));

			Socket client_socket = new Socket("localhost", serverport);

			if (client_socket.isConnected()) {

				listenport = client_socket.getLocalPort() + 5;

				System.out.println("TCP Client connected to " + client_socket.getInetAddress() +

				" on port " + client_socket.getPort());

				PrintWriter clout = new PrintWriter(client_socket.getOutputStream(), true);

				clout.println(fname);
				clout.println(client_socket.getLocalAddress().getHostName());
				clout.println((client_socket.getLocalPort() + 5));
				clout.println(2);
				clout.println(1);
				clout.println("true");
				clout.flush();
				client_socket.close();

			}

			ServerSocket serv = null;

			serv = new ServerSocket(listenport);
			Socket s = null;
			s = serv.accept();

			byte[] mybytearray = new byte[1024];
			InputStream is = s.getInputStream();
			FileOutputStream fos = new FileOutputStream("TABC.txt");
			BufferedOutputStream bos = new BufferedOutputStream(fos);
			int bytesRead = is.read(mybytearray, 0, mybytearray.length);
			bos.write(mybytearray, 0, bytesRead);
			bos.flush();
			bos.close();
			s.close();
			serv.close();

			// BufferedReader br;
			//
			// br = new BufferedReader(new
			// InputStreamReader(s.getInputStream()));

			// System.out.println(br.readLine());

		} else {
			System.out.println("Incorrect Option.");
		}

	}

	private static void insertFile(String fname) throws IOException {
		// TODO Auto-generated method stub

		int serverport = getServerIP(fname, 0, 0);

		int port = serverport + 5;
		int fport = serverport + 10;
		Socket client_socket = new Socket("localhost", port);

		if (client_socket.isConnected()) {

			System.out.println("TCP Client connected to " + client_socket.getInetAddress() +

			" on port " + client_socket.getPort());

			PrintWriter clout = new PrintWriter(client_socket.getOutputStream(), true);

			clout.println(fname);
			clout.flush();
			client_socket.close();

			Socket soc = new Socket("localhost", fport);

			if (soc.isConnected()) {

				System.out.println("At Client inserting file :");
				File myFile = new File(fname);

				byte[] mybytearray1 = new byte[(int) myFile.length()];
				BufferedInputStream bis = new BufferedInputStream(new FileInputStream(myFile));
				bis.read(mybytearray1, 0, mybytearray1.length);
				OutputStream os = soc.getOutputStream();
				os.write(mybytearray1, 0, mybytearray1.length);
				os.flush();
				soc.close();
			}
		}

	}

	static int getServerIP(String filename, int i, int j) {

		HashMap<Integer, Integer> servermap = new HashMap<Integer, Integer>();

		servermap.put(0, 10000);
		servermap.put(1, 10100);
		servermap.put(2, 10200);
		servermap.put(3, 10300);
		servermap.put(4, 10400);
		servermap.put(5, 10500);
		servermap.put(6, 10600);

		int rootindex = Math.abs((filename.hashCode()) % 7);

	
		if (i == 0) {
			return servermap.get(rootindex);
		} else if (i == 1) {

			if (j == 0) {
				return servermap.get((rootindex + 1) % 7);
			} else {
				return servermap.get((rootindex + 2) % 7);
			}

		}

		else {

			return servermap.get((rootindex + 3 + j) % 7);

		}

	}

}
