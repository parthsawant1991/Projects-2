import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

/**
 * this class contains the implementation of the Vector time
 * 
 * @author Parth
 *
 */
public class Problem2Process1 {

	public static int balance = 1000; // initial balance

	public static int serverport1 = 11000; // receiver port form process 2
	public static int serverport2 = 12000; // receiver port from process 3
	public static String servername;

	public static int processport1 = 22010; // sender port to process 2

	public static int processport2 = 33000; // sender port to process 3

	public static String processname1 = "localhost"; // process 2 server name
	public static String processname2 = "localhost"; // process 3 server name

	public static int vector[];

	/*
	 * the synchronized get method ensures that concurrent access to the
	 * variable does not take place
	 */
	synchronized static int getBalance() {
		return Problem2Process1.balance;
	}

	/*
	 * the synchronized set method ensures that concurrent access to the
	 * variable does not take place
	 */
	synchronized static void setBalance(int bal) {
		Problem2Process1.balance = bal;
	}

	/*
	 * this is the main thread of execution responsible for the execution of the
	 * deposit, withdraw and send money operations
	 */
	public static void main(String[] args) throws UnknownHostException, IOException, InterruptedException {
		// TODO Auto-generated method stub

		vector = new int[3];
		vector[0] = 0;
		vector[1] = 0;
		vector[2] = 0;

		// start receiver thread

		System.out.println("starting receiver thread");

		/*
		 * we will start the receiver threads for the two processes, these
		 * behave as an incoming channel used for receiving money
		 */
		new Thread(new Process1Receiver1()).start();
		new Thread(new Process1Receiver2()).start();

		System.out.println("starting loop");
		Thread.sleep(4000);

		int count = 10;

		// start transaction loop

		while (count > 0) {

			Thread.sleep(5000);

			int randomserver = (int) (Math.random() * 1000 % 2);

			int randomoperation = (int) (Math.random() * 1000 % 3);

			int randomamount = (int) (Math.random() * 1000 % 100);

			if (randomoperation == 0) {

				System.out.println("Deposit money ");
				System.out.println((++vector[0]) + " " + vector[1] + " " + vector[2]);
				int bal = Problem2Process1.getBalance();
				bal += randomamount;
				Problem2Process1.setBalance(bal);
				System.out.println("Current Balance " + balance);

			} else if (randomoperation == 1) {

				System.out.println("Withdraw money ");
				System.out.println((++vector[0]) + " " + vector[1] + " " + vector[2]);
				int bal = Problem2Process1.getBalance();
				bal -= randomamount;
				Problem2Process1.setBalance(bal);
				System.out.println("Current Balance " + balance);

			} else if (randomoperation == 2) {

				System.out.println("Send money to " + randomserver);

				System.out.println((++vector[0]) + " " + vector[1] + " " + vector[2]);

				int bal = Problem2Process1.getBalance();
				bal -= randomamount;
				Problem2Process1.setBalance(bal);

				if (randomserver == 0) {

					@SuppressWarnings("resource")
					Socket clientsocket = new Socket(Problem2Process1.processname1, Problem2Process1.processport1);

					if (clientsocket.isConnected()) {

						PrintWriter clientout = new PrintWriter(clientsocket.getOutputStream(), true);

						clientout.println(randomamount);
						clientout.println(vector[0]);
						clientout.flush();
						clientout.close();

					}
					clientsocket.close();

				}

				else if (randomserver == 1) {
					@SuppressWarnings("resource")
					Socket clientsocket = new Socket(Problem2Process1.processname2, Problem2Process1.processport2);

					if (clientsocket.isConnected()) {

						PrintWriter clientout = new PrintWriter(clientsocket.getOutputStream(), true);

						clientout.println(randomamount);
						clientout.println(vector[0]);
						clientout.flush();
						clientout.close();

					}
					clientsocket.close();

				}

			}

			else {

			}

			count--;
		}

		Thread.sleep(10000);
		System.exit(0);

	}
}

/*
 * this is the receiver thread implementation for a process
 */
class Process1Receiver1 implements Runnable {

	public Process1Receiver1() {

	}

	@SuppressWarnings("resource")
	@Override
	public void run() {
		// TODO Auto-generated method stub

		try {

			/*
			 * this is listening for any incoming communication to receive money
			 */
			while (true) {

				ServerSocket receivesocket = null;

				Socket receive = null;

				receivesocket = new ServerSocket(Problem2Process1.serverport1);

				receive = receivesocket.accept();

				BufferedReader br = new BufferedReader(new InputStreamReader(receive.getInputStream()));

				int incomingBal = Integer.parseInt(br.readLine());

				int incomingvector = Integer.parseInt(br.readLine());

				Problem2Process1.vector[1] = Math.max(incomingvector, Problem2Process1.vector[1]);

				System.out.println("Incoming balance " + incomingBal);

				System.out.println("Current Balance " + (Problem2Process1.balance + incomingBal));

				int bal = Problem2Process1.getBalance();
				bal += incomingBal;
				Problem2Process1.setBalance(bal);

				System.out.println((++Problem2Process1.vector[0]) + " " + (Problem2Process1.vector[1]) + " "
						+ Problem2Process1.vector[2]);

				receive.close();

				receivesocket.close();

			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}

/*
 * this is the receiver thread implementation for a process
 */
class Process1Receiver2 implements Runnable {

	public Process1Receiver2() {

	}

	@SuppressWarnings("resource")
	@Override
	public void run() {
		// TODO Auto-generated method stub

		try {

			/*
			 * this is listening for any incoming communication to receive money
			 */
			while (true) {

				ServerSocket receivesocket = null;

				Socket receive = null;

				receivesocket = new ServerSocket(Problem2Process1.serverport2);

				receive = receivesocket.accept();

				BufferedReader br = new BufferedReader(new InputStreamReader(receive.getInputStream()));

				int incomingBal = Integer.parseInt(br.readLine());

				int incomingvector = Integer.parseInt(br.readLine());

				Problem2Process1.vector[2] = Math.max(incomingvector, Problem2Process1.vector[2]);

				System.out.println("Incoming balance " + incomingBal);

				System.out.println("Current Balance " + (Problem2Process1.balance + incomingBal));

				int bal = Problem2Process1.getBalance();
				bal += incomingBal;
				Problem2Process1.setBalance(bal);

				System.out.println((++Problem2Process1.vector[0]) + " " + Problem2Process1.vector[1] + " "
						+ (Problem2Process1.vector[2]));
				receive.close();

				receivesocket.close();

			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
