import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Problem2Process3 {

	public static int balance = 1000;

	public static int serverport1 = 33000; // receiver port from process 1

	public static int serverport2 = 34000; // receiver port from process 2

	public static String servername;

	public static int processport1 = 12000; // sender port for process 1

	public static int processport2 = 23010; // sender port for process 2

	public static String processname1 = "localhost";
	public static String processname2 = "localhost";

	public static int vector[];

	synchronized static int getBalance() {
		return Problem2Process3.balance;
	}

	synchronized static void setBalance(int bal) {
		Problem2Process3.balance = bal;
	}

	public static void main(String[] args) throws UnknownHostException, IOException, InterruptedException {
		// TODO Auto-generated method stub

		vector = new int[3];
		vector[0] = 0;
		vector[1] = 0;
		vector[2] = 0;

		// start receiver thread

		System.out.println("starting receiver thread");

		new Thread(new Process3Receiver1()).start();
		new Thread(new Process3Receiver2()).start();

		System.out.println("starting loop");

		Thread.sleep(4000);

		int count = 10;

		// start transaction loop

		while (count > 0) {

			Thread.sleep(5000);

			int randomserver = (int) (Math.random() * 1000 % 2);

			int randomoperation = (int) (Math.random() * 1000 % 3);

			int randomamount = (int) (Math.random() * 1000 % 100);

			// System.out.println(randomserver + " " + randomoperation + " " +
			// randomamount);

			if (randomoperation == 0) {

				System.out.println("Deposit money ");
				System.out.println((vector[0]) + " " + vector[1] + " " + (++vector[2]));
				int bal = Problem2Process3.getBalance();
				bal += randomamount;
				Problem2Process3.setBalance(bal);
				System.out.println("Current Balance " + balance);

			} else if (randomoperation == 1) {

				System.out.println("Withdraw money ");
				System.out.println((vector[0]) + " " + vector[1] + " " + (++vector[2]));
				int bal = Problem2Process3.getBalance();
				bal -= randomamount;
				Problem2Process3.setBalance(bal);
				System.out.println("Current Balance " + balance);

			} else if (randomoperation == 2) {

				System.out.println("Send money to " + randomserver);

				System.out.println((vector[0]) + " " + vector[1] + " " + (++vector[2]));

				int bal = Problem2Process3.getBalance();
				bal -= randomamount;
				Problem2Process3.setBalance(bal);

				if (randomserver == 0) {

					@SuppressWarnings("resource")
					Socket clientsocket = new Socket(Problem2Process3.processname1, Problem2Process3.processport1);

					if (clientsocket.isConnected()) {

						PrintWriter clientout = new PrintWriter(clientsocket.getOutputStream(), true);

						clientout.println(randomamount);
						clientout.println(vector[2]);
						clientout.flush();
						clientout.close();

					}
					clientsocket.close();

				}

				else if (randomserver == 1) {
					@SuppressWarnings("resource")
					Socket clientsocket = new Socket(Problem2Process3.processname2, Problem2Process3.processport2);

					if (clientsocket.isConnected()) {

						PrintWriter clientout = new PrintWriter(clientsocket.getOutputStream(), true);

						clientout.println(randomamount);
						clientout.println(vector[2]);
						clientout.flush();
						clientout.close();

					}
					clientsocket.close();

				}

			}

			else {

			}

			count--;
		}

		Thread.sleep(10000);
		System.exit(0);
	}
}

class Process3Receiver1 implements Runnable {

	public Process3Receiver1() {

	}

	@SuppressWarnings("resource")
	@Override
	public void run() {
		// TODO Auto-generated method stub

		try {

			while (true) {

				ServerSocket receivesocket = null;

				Socket receive = null;

				receivesocket = new ServerSocket(Problem2Process3.serverport1);

				receive = receivesocket.accept();

				// create thread here

				BufferedReader br = new BufferedReader(new InputStreamReader(receive.getInputStream()));

				int incomingBal = Integer.parseInt(br.readLine());

				int incomingvector = Integer.parseInt(br.readLine());

				Problem2Process3.vector[0] = Math.max(incomingvector, Problem2Process3.vector[0]);

				System.out.println("Incoming balance " + incomingBal);

				System.out.println("Current Balance " + (Problem2Process3.balance + incomingBal));

				int bal = Problem2Process3.getBalance();
				bal += incomingBal;
				Problem2Process3.setBalance(bal);

				System.out.println((Problem2Process3.vector[0]) + " " + Problem2Process3.vector[1] + " "
						+ (++Problem2Process3.vector[2]));

				receive.close();

				receivesocket.close();

			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}

class Process3Receiver2 implements Runnable {

	public Process3Receiver2() {

	}

	@SuppressWarnings("resource")
	@Override
	public void run() {
		// TODO Auto-generated method stub

		try {

			while (true) {

				ServerSocket receivesocket = null;

				Socket receive = null;

				receivesocket = new ServerSocket(Problem2Process3.serverport2);

				receive = receivesocket.accept();

				// create thread here

				BufferedReader br = new BufferedReader(new InputStreamReader(receive.getInputStream()));

				int incomingBal = Integer.parseInt(br.readLine());
				int incomingvector = Integer.parseInt(br.readLine());

				Problem2Process3.vector[1] = Math.max(incomingvector, Problem2Process3.vector[1]);

				System.out.println("Incoming balance " + incomingBal);

				System.out.println("Current Balance " + (Problem2Process3.balance + incomingBal));

				int bal = Problem2Process3.getBalance();
				bal += incomingBal;
				Problem2Process3.setBalance(bal);

				System.out.println(Problem2Process3.vector[0] + " " + (Problem2Process3.vector[1]) + " "
						+ (++Problem2Process3.vector[2]));
				receive.close();

				receivesocket.close();

			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
