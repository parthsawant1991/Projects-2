import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.ArrayList;

/*
 * this class contains the implementation of the trainer program to generate a decision tree classifier
 */
public class HW_04_Sawant_Parth_Trainer {

	static File f;

	static FileOutputStream fout;

	static PrintWriter pw;

	/*
	 * this is the main thread of execution
	 */
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		System.out.println("Decision Tree Builder:");

		String csvFile = "HW_04_DecTree_Training__v101.csv";
		BufferedReader br = new BufferedReader(new FileReader(csvFile));

		String line = "";
		String csvSplit = ",";
		String[] input = null;

		ArrayList<ArrayList<Double>> data = new ArrayList<ArrayList<Double>>(); // an
																				// arraylist
																				// of
																				// arraylist
																				// is
																				// used
																				// to
																				// store
																				// the
																				// incoming
																				// data

		int zerocount = 0;
		int onecount = 0;
		int total = 0;
		double[] minatt = new double[4];
		minatt[0] = 0;
		minatt[1] = 0;
		minatt[2] = 0;
		minatt[3] = 0;

		double[] maxatt = new double[4];
		maxatt[0] = 0;
		maxatt[1] = 0;
		maxatt[3] = 0;
		maxatt[3] = 0;

		/*
		 * reading the csv file
		 */
		while ((line = br.readLine()) != null) {

			input = line.split(csvSplit);

			ArrayList<Double> tuple = new ArrayList<Double>();

			tuple.add(Double.parseDouble(input[0])); // attribute 1
			if (tuple.get(0) <= minatt[0]) {
				minatt[0] = tuple.get(0);
			}
			if (tuple.get(0) >= maxatt[0]) {
				maxatt[0] = tuple.get(0);
			}

			tuple.add(Double.parseDouble(input[1])); // attribute 2
			if (tuple.get(1) <= minatt[1]) {
				minatt[1] = tuple.get(1);
			}
			if (tuple.get(1) >= maxatt[1]) {
				maxatt[1] = tuple.get(1);
			}
			tuple.add(Double.parseDouble(input[2])); // attribute 3
			if (tuple.get(2) <= minatt[2]) {
				minatt[2] = tuple.get(2);
			}
			if (tuple.get(2) >= maxatt[2]) {
				maxatt[2] = tuple.get(2);
			}
			tuple.add(Double.parseDouble(input[3])); // attribute 4
			if (tuple.get(3) <= minatt[3]) {
				minatt[3] = tuple.get(3);
			}
			if (tuple.get(3) >= maxatt[3]) {
				maxatt[3] = tuple.get(3);
			}
			tuple.add(Double.parseDouble(input[4])); // class value

			tuple.add(-1.0); // flag to denote if already classified

			if (tuple.get(4) == 1) {
				onecount++;
			} else if (tuple.get(4) == 0) {
				zerocount++;
			} else {
				System.out.println("Incorrect training class: ");
			}

			total++;

			data.add(tuple);

		}

		/*
		 * this is the classifier file being written prologue
		 */
		f = new File("HW04_Sawant_Parth_Classifier.java");

		fout = new FileOutputStream(f);

		pw = new PrintWriter(new OutputStreamWriter(fout));

		pw.println("import java.io.*;");
		pw.println("import java.util.*;");
		pw.println("public class HW04_Sawant_Parth_Classifier {");
		pw.println("	public static void main(String[] args) throws NumberFormatException, IOException { ");
		pw.println("System.out.println(\"Decision Tree Classifier:\");");
		pw.println("File f = new File(\"HW_04_Sawant_Parth_MyClassifications.txt\");");
		pw.println("FileOutputStream fout = new FileOutputStream(f);");
		pw.println("PrintWriter pw = new PrintWriter(new OutputStreamWriter(fout));");
		pw.println("String csvFile = \"HW_04_DecTree_Testing__Data_TO_CLASSIFY__v101.csv\";");
		pw.println("	BufferedReader br = new BufferedReader(new FileReader(csvFile));");
		pw.println("String line = \"\";");
		pw.println("String csvSplit = \",\";");
		pw.println("String[] input = null;");
		pw.println("ArrayList<ArrayList<Double>> data = new ArrayList<ArrayList<Double>>();");
		pw.println("	while ((line = br.readLine()) != null) {");
		pw.println("	input = line.split(csvSplit);");
		pw.println("	ArrayList<Double> tuple = new ArrayList<Double>();");
		pw.println("	tuple.add(Double.parseDouble(input[0])); ");
		pw.println("	tuple.add(Double.parseDouble(input[1]));");
		pw.println("tuple.add(Double.parseDouble(input[2]));");
		pw.println("tuple.add(Double.parseDouble(input[3])); ");
		pw.println("data.add(tuple);");
		pw.println("for(int i = 0 ; i < data.size();i++){ ");
		pw.println("ArrayList<Double> att = data.get(i);");

		/*
		 * this is the classifier logic
		 */

		getClasses(data, minatt, maxatt);

		pw.println("}");
		pw.println("}");
		pw.println("pw.flush();");
		pw.println("pw.close();");
		pw.println("}");
		pw.println("}");
		pw.flush();
		pw.close();
	}

	/*
	 * this method recursively computed the best threshold to classify the data
	 * based on the structure of decision tree
	 */
	static void getClasses(ArrayList<ArrayList<Double>> data, double[] minatt, double[] maxatt) {

		// if (data.size() <= 1) {
		// return;
		// }

		double[] threshatt = new double[4];
		double[] minmix = new double[4];
		double belowzcount = 0;
		double belowocount = 0;
		double abvzcount = 0;
		double abvocount = 0;
		double pzerobel = 0;
		double ponebel = 0;
		double pzeroabv = 0;
		double poneabv = 0;
		double valsbelow = 0;
		double valsabv = 0;
		double minemix = 1000;
		double bestthresh = 0;

		for (int a = 0; a < 4; a++) {

			for (double i = minatt[a]; i < maxatt[a]; i++) {

				for (int j = 0; j < data.size(); j++) {

					ArrayList<Double> arr = data.get(j);

					double val = arr.get(4);
					double attributeValue = arr.get(a);

					if (val == 1 && attributeValue <= i) {
						belowocount++;
						valsbelow++;

					} else if (val == 1 && attributeValue > i) {
						abvocount++;
						valsabv++;
					} else if (val == 0 && attributeValue <= i) {
						belowzcount++;
						valsbelow++;
					} else {
						abvzcount++;
						valsabv++;
					}

				}

				if (valsbelow != 0) {
					pzerobel = -(belowzcount / valsbelow) * (Math.log(belowzcount / valsbelow) / Math.log(2));
					ponebel = -(belowocount / valsbelow) * (Math.log(belowocount / valsbelow) / Math.log(2));
				}

				else {
					pzerobel = 0;
					ponebel = 0;
				}
				if (valsabv != 0) {
					pzeroabv = -(abvzcount / valsabv) * (Math.log(abvzcount / valsabv) / Math.log(2));
					poneabv = -(abvocount / valsabv) * (Math.log(abvocount / valsabv) / Math.log(2));
				} else {
					poneabv = 0;
					pzeroabv = 0;
				}

				if (belowocount == 0) {
					ponebel = 0;
				}
				if (belowzcount == 0) {
					pzerobel = 0;
				}
				if (abvocount == 0) {
					poneabv = 0;
				}
				if (abvzcount == 0) {
					pzeroabv = 0;
				}

				/*
				 * this computes the mixed entropy
				 */
				double emix = (valsbelow / data.size() * (pzerobel + ponebel))
						+ (valsabv / data.size() * (pzeroabv + poneabv));

				if (emix <= minemix) {
					minemix = emix;
					bestthresh = i;
				}

				belowzcount = 0;
				belowocount = 0;
				abvzcount = 0;
				abvocount = 0;
				pzerobel = 0;
				ponebel = 0;
				pzeroabv = 0;
				poneabv = 0;
				valsbelow = 0;
				valsabv = 0;

			}

			threshatt[a] = bestthresh;
			minmix[a] = minemix;

			minemix = 1000;
			bestthresh = 0;
		}

		double bestminmix = 100; // best mixed entropy
		double classthresh = -1; // corresponding threshold
		int att = -1; // the attribute under consideration

		for (int i = 0; i < 4; i++) {
			if (bestminmix >= minmix[i]) {
				bestminmix = minmix[i];
				att = i;
				classthresh = threshatt[i];
			}
		}
		ArrayList<ArrayList<Double>> class0 = new ArrayList<ArrayList<Double>>();
		ArrayList<ArrayList<Double>> class1 = new ArrayList<ArrayList<Double>>();

		for (int x = 0; x < data.size(); x++) {

			ArrayList<Double> arr = data.get(x);

			if (arr.get(att) >= classthresh) {

				class0.add(arr);
			} else {
				// arr.add(5, 0.0);
				class1.add(arr);
			}

		}

		int class0zcount = 0;
		int class0ocount = 0;

		int class1zcount = 0;
		int class1ocount = 0;

		for (int x = 0; x < class0.size(); x++) {
			ArrayList<Double> vals = class0.get(x);

			if (vals.get(4) == 0) {
				class0zcount++;
			} else {
				class0ocount++;
			}

		}

		int purity0 = 100 * (Math.max(class0zcount, class0ocount) - Math.min(class0zcount, class0ocount))
				/ (class0zcount + class0ocount);

		for (int x = 0; x < class1.size(); x++) {
			ArrayList<Double> vals = class1.get(x);
			if (vals.get(4) == 0) {
				class1zcount++;
			} else {
				class1ocount++;
			}

		}

		int purity1 = 100 * (Math.max(class1zcount, class1ocount) - Math.min(class1zcount, class1ocount))
				/ (class1zcount + class1ocount);

		if (purity1 > 90 || purity0 > 90) {
			System.out.println("if(att.get(" + att + ")<=" + classthresh + "){");
			pw.println("if(att.get(" + att + ")<=" + classthresh + "){");
		}

		if (purity1 > 90) {
			System.out.println("identify as 1");
			pw.println("pw.println(\"1\");");
			pw.println("}");

		} else {
			getClasses(class1, minatt, maxatt);
			System.out.println("}");
			pw.println("}");
		}
		System.out.println("else{");
		pw.println("else{");
		if (purity0 > 90) {
			System.out.println("identify as 0");
			pw.println("pw.println(\"0\");");
			System.out.println("}");
			pw.println("}");

		} else {
			getClasses(class0, minatt, maxatt);
		}

	}

}
