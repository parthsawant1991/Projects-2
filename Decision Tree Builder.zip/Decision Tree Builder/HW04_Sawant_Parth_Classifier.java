import java.io.*;
import java.util.*;

public class HW04_Sawant_Parth_Classifier {
	public static void main(String[] args) throws NumberFormatException, IOException {
		System.out.println("Decision Tree Classifier:");
		File f = new File("HW_04_Sawant_Parth_MyClassifications.txt");
		FileOutputStream fout = new FileOutputStream(f);
		PrintWriter pw = new PrintWriter(new OutputStreamWriter(fout));
		String csvFile = "HW_04_DecTree_Testing__Data_TO_CLASSIFY__v101.csv";
		BufferedReader br = new BufferedReader(new FileReader(csvFile));
		String line = "";
		String csvSplit = ",";
		String[] input = null;
		ArrayList<ArrayList<Double>> data = new ArrayList<ArrayList<Double>>();
		while ((line = br.readLine()) != null) {
			input = line.split(csvSplit);
			ArrayList<Double> tuple = new ArrayList<Double>();
			tuple.add(Double.parseDouble(input[0]));
			tuple.add(Double.parseDouble(input[1]));
			tuple.add(Double.parseDouble(input[2]));
			tuple.add(Double.parseDouble(input[3]));
			data.add(tuple);
			for (int i = 0; i < data.size(); i++) {
				ArrayList<Double> att = data.get(i);
				if (att.get(1) <= 8.0) {
					if (att.get(1) <= 5.0) {
						if (att.get(0) <= 5.0) {
							pw.println("1");
						} else {
							pw.println("0");
						}
					} else {
						pw.println("0");
					}
				} else {
					pw.println("0");
				}
			}
		}
		pw.flush();
		pw.close();
	}
}
