import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.Iterator;

public class NodeServer2 {

	static HashMap<Integer, Integer> filedir = new HashMap<Integer, Integer>();

	static String servername = "localhost";
	static int serverport = 36787;
	static int hashrange = 900;
	static int hashbegin = 100;
	static int hashend = 1000;
	static String successor = "localhost";
	static int successorport = 36465;
	static String predecessor = "localhost";
	static int predecessorport = 0;

	static int hashvalue = 100;
	static String clientname;
	static int clientport;
	static boolean isSet = false;

	static boolean isFileRequest;
	static boolean isFileInsert;

	static boolean isNodeJoin;
	static boolean isNodeLeave;

	static String newSuccessor;
	static String newPredecessor;

	@SuppressWarnings("resource")
	public static void main(String[] args) throws IOException, InterruptedException {
		// TODO Auto-generated method stub

		if (args.length > 0) {
			NodeServer2.servername = args[0];
			NodeServer2.serverport = Integer.parseInt(args[1]);
			NodeServer2.hashbegin = Integer.parseInt(args[2]);

		}

		// initial join mechanism inside loop

		while (!isSet) {

			// send request
			Thread.sleep(2000);

			System.out.println("requesting id space");
			Socket servtoserv = new Socket(NodeServer2.successor, NodeServer2.successorport);

			clientname = servtoserv.getLocalAddress().getHostName();
			clientport = servtoserv.getLocalPort();
			isFileRequest = false;
			isFileInsert = false;
			isNodeJoin = true;
			isNodeLeave = false;
			newSuccessor = "";
			newPredecessor = "";

			if (servtoserv.isConnected()) {

				System.out.println("connected to: " + servtoserv.getInetAddress().getHostName());
				PrintWriter clientout = new PrintWriter(servtoserv.getOutputStream(), true);
				// BufferedReader br = new BufferedReader(new
				// InputStreamReader(servtoserv.getInputStream()));

				clientout.println(hashbegin);
				clientout.println(servername);
				clientout.println(serverport);
				clientout.println(isFileRequest);
				clientout.println(isFileInsert);
				clientout.println(isNodeJoin);
				clientout.println(isNodeLeave);
				clientout.println("false");
				clientout.println(newSuccessor);
				clientout.println(newPredecessor);
				clientout.flush();
				clientout.close();

				ServerSocket serv = new ServerSocket(9876);
				Socket soc = serv.accept();

				BufferedReader br = new BufferedReader(new InputStreamReader(soc.getInputStream()));
				System.out.println("reply");

				NodeServer2.hashvalue = Integer.parseInt(br.readLine());
				NodeServer2.clientname = br.readLine();
				NodeServer2.clientport = Integer.parseInt(br.readLine());

				NodeServer2.isFileRequest = Boolean.parseBoolean(br.readLine());
				NodeServer2.isFileInsert = Boolean.parseBoolean(br.readLine());

				NodeServer2.isNodeJoin = Boolean.parseBoolean(br.readLine());
				NodeServer2.isNodeLeave = Boolean.parseBoolean(br.readLine());
				NodeServer2.isSet = Boolean.parseBoolean(br.readLine());

				NodeServer2.successor = br.readLine();
				NodeServer2.successorport = Integer.parseInt(br.readLine());

				NodeServer2.predecessor = br.readLine();
				
				String line = null;
				while((br.readLine())!=null){
					System.out.println(line);
				}
				
				soc.close();
				serv.close();

				/*
				 * ID space found
				 */
				if (isSet) {					
									

					System.out.println("id space found");

					// successorport = NodeServer2.successorport;
					predecessor = NodeServer2.clientname;
					predecessorport = NodeServer2.clientport;
					System.out.println("new successor: " + successorport);

					System.out.println("new predecessor: " + predecessorport);

					System.out.println("update current ID space");

					System.out.println("notify successor to change successor");

					// update predecessor

//					Socket servtosucc = new Socket("localhost", NodeServer2.predecessorport);
//
//					if (servtosucc.isConnected()) {
//
//						PrintWriter servout = new PrintWriter(servtosucc.getOutputStream(), true);
//
//						servout.println(hashvalue);
//						servout.println(clientname);
//						servout.println(clientport);
//						servout.println(false);
//						servout.println(false);
//						servout.println(false);
//						servout.println(false);
//						servout.println(false);
//						servout.println("");
//						servout.println(NodeServer2.serverport);
//						servout.flush();
//						servout.close();
//
//					}
//
//					servtosucc.close();

					//

				}
				/*
				 * ID space not found, forward request to next server
				 */
				else {

					System.out.println("id space not found, forwarding request to next server");

					// successorport = NodeServer2.successorport;
					predecessor = NodeServer2.newPredecessor;
					System.out.println("new successor: " + successorport);

				}

			}

			servtoserv.close();

		}

		// start listener thread

		ServerSocket nodesocket = null;
		nodesocket = new ServerSocket(serverport);
		while (true) {

			Socket sock = null;
			sock = nodesocket.accept();

			new Thread(new NodeListener2(sock)).start();

		}

	}

}

class NodeListener2 implements Runnable {

	Socket listensocket;

	public NodeListener2(Socket sock) {
		// TODO Auto-generated constructor stub
		this.listensocket = sock;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub

		try {

			BufferedReader br = new BufferedReader(new InputStreamReader(listensocket.getInputStream()));

			NodeServer2.hashvalue = Integer.parseInt(br.readLine());
			NodeServer2.clientname = br.readLine();
			NodeServer2.clientport = Integer.parseInt(br.readLine());

			NodeServer2.isFileRequest = Boolean.parseBoolean(br.readLine());
			NodeServer2.isFileInsert = Boolean.parseBoolean(br.readLine());

			NodeServer2.isNodeJoin = Boolean.parseBoolean(br.readLine());
			NodeServer2.isNodeLeave = Boolean.parseBoolean(br.readLine());
			NodeServer2.isSet = Boolean.parseBoolean(br.readLine());

			String tempsuccessor = br.readLine();

			// NodeServer2.newSuccessor = br.readLine();
			NodeServer2.newPredecessor = br.readLine();
//
//			if (NodeServer2.newPredecessor != "") {
//
//				NodeServer2.predecessorport = Integer.parseInt(NodeServer2.newPredecessor);
//				System.out.println("predecessor updeated to: " + NodeServer2.predecessorport);
//
//			}

			int temp = 0;

			if (NodeServer2.isNodeJoin) {

				System.out.println("node join");

				if (NodeServer2.hashvalue >= NodeServer2.hashbegin && NodeServer2.hashvalue <= NodeServer2.hashend) {

					NodeServer2.hashend = NodeServer2.hashvalue - 1;
					NodeServer2.isSet = true;

					System.out.println("new hash range " + NodeServer2.hashbegin + " " + NodeServer2.hashend);

					temp = NodeServer2.clientport;

				}

				Socket s = new Socket("localhost", 9876);
				if (s.isConnected()) {

					PrintWriter clientout = new PrintWriter(s.getOutputStream(), true);

					clientout.println(NodeServer2.hashvalue);
					clientout.println(NodeServer2.servername);
					clientout.println(NodeServer2.serverport);
					clientout.println(NodeServer2.isFileRequest);
					clientout.println(NodeServer2.isFileInsert);
					clientout.println(NodeServer2.isNodeJoin);
					clientout.println(NodeServer2.isNodeLeave);
					clientout.println(NodeServer2.isSet);
					clientout.println(NodeServer2.successor);
					clientout.println(NodeServer2.successorport);
					clientout.println(NodeServer2.serverport);
					
					if (NodeServer2.isSet) {

						Iterator it = NodeServer2.filedir.entrySet().iterator();
						while (it.hasNext()) {
							HashMap.Entry pair = (HashMap.Entry) it.next();
							// System.out.println(pair);
							Integer k = (Integer) pair.getKey();
							// System.out.println(k);
							// System.out.println(NodeServer2.hashend);

							if (k > NodeServer2.hashend) {
								clientout.println(k);
								System.out.println(pair + " rehash");
							}
							it.remove(); // avoids a
											// ConcurrentModificationException
						}

					}
					
					clientout.flush();
					clientout.close();

					NodeServer2.isSet = false;

				}
				s.close();

				NodeServer2.successorport = temp;

				System.out.println("new successor: " + NodeServer2.successorport);

				return;

			}

			if (NodeServer2.hashvalue >= NodeServer2.hashbegin && NodeServer2.hashvalue <= (NodeServer2.hashend)) {

				System.out.println("Server Hit");

				/*
				 * node removal request
				 */
				if (NodeServer2.isNodeLeave && NodeServer2.hashvalue == NodeServer2.hashbegin) {

					System.out.println("removal of server");

				}

				if (NodeServer2.isFileRequest) {

					if (NodeServer2.filedir.containsKey(NodeServer2.hashvalue)) {
						System.out.println("file request");
					} else {
						System.out.println("file not found");
					}

				} else if (NodeServer2.isFileInsert) {

					System.out.println("file insert");
					NodeServer2.filedir.put(NodeServer2.hashvalue, NodeServer2.hashvalue);

				} else if (NodeServer2.isNodeJoin) {

					System.out.println("node join");

				} else if (NodeServer2.isNodeLeave) {

					System.out.println("node leave");

				} else {

					System.out.println("incorrect message");
				}

			} else {

				System.out.println("forward request to sucessor: " + NodeServer2.successor);

				Socket servtosucc = new Socket(NodeServer2.successor, NodeServer2.successorport);

				if (servtosucc.isConnected()) {

					PrintWriter servout = new PrintWriter(servtosucc.getOutputStream(), true);

					servout.println(NodeServer2.hashvalue);
					servout.println(NodeServer2.clientname);
					servout.println(NodeServer2.clientport);
					servout.println(NodeServer2.isFileRequest);
					servout.println(NodeServer2.isFileInsert);
					servout.println(NodeServer2.isNodeJoin);
					servout.println(NodeServer2.isNodeLeave);
					servout.println(NodeServer2.newSuccessor);
					servout.println("");
					servout.flush();
					servout.close();

				}

				servtosucc.close();

			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}