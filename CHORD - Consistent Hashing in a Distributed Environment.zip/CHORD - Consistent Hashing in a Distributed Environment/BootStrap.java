import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class BootStrap {

	static int port = 36465;

	static String servername = "localhost";
	static int serverport = 36678;

	static int hashvalue;
	static String clientname;
	static int clientport;

	static boolean isFileRequest;
	static boolean isFileInsert;

	static boolean isNodeJoin;
	static boolean isNodeLeave;

	static String newSuccessor;
	static String newPredecessor;

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		if (args.length > 0) {
			BootStrap.servername = args[0];
			BootStrap.serverport = Integer.parseInt(args[1]);

		}

		while (true) {

			ServerSocket bootsocket = null;
			try {
				bootsocket = new ServerSocket(port);

				while (true) {
					Socket socket = null;
					socket = bootsocket.accept();
					new Thread(new BootStrapListener(socket)).start();

				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

	}

	class BootStrapWriter implements Runnable {

		@Override
		public void run() {
			// TODO Auto-generated method stub

		}

	}
}

class BootStrapListener implements Runnable {

	Socket bootsock;

	public BootStrapListener(Socket socket) {
		// TODO Auto-generated constructor stub
		this.bootsock = socket;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub

		BufferedReader br;
		try {
			br = new BufferedReader(new InputStreamReader(bootsock.getInputStream()));

			BootStrap.hashvalue = Integer.parseInt(br.readLine());
			BootStrap.clientname = br.readLine();
			BootStrap.clientport = Integer.parseInt(br.readLine());

			BootStrap.isFileRequest = Boolean.parseBoolean(br.readLine());
			BootStrap.isFileInsert = Boolean.parseBoolean(br.readLine());

			BootStrap.isNodeJoin = Boolean.parseBoolean(br.readLine());
			BootStrap.isNodeLeave = Boolean.parseBoolean(br.readLine());
			boolean isSet = Boolean.parseBoolean(br.readLine());

			BootStrap.newSuccessor = br.readLine();
			BootStrap.newPredecessor = br.readLine();

			System.out.println("request received");
			/*
			 * legal hash, forward request to server
			 */
			if (BootStrap.hashvalue < 1024) {
				

				if (BootStrap.isNodeJoin) {

					System.out.println("node join request");
					
					

					Socket s = new Socket("localhost", 9876);
					if (s.isConnected()) {

						PrintWriter clientout = new PrintWriter(s.getOutputStream(), true);

						clientout.println(BootStrap.hashvalue);
						clientout.println(BootStrap.clientname);
						clientout.println(BootStrap.clientport);
						clientout.println(BootStrap.isFileRequest);
						clientout.println(BootStrap.isFileInsert);
						clientout.println(BootStrap.isNodeJoin);
						clientout.println(BootStrap.isNodeLeave);
						clientout.println("false");
						clientout.println(BootStrap.servername);
						clientout.println(BootStrap.serverport);
						clientout.println(BootStrap.port);
						clientout.flush();
						clientout.close();

					}
					s.close();

					 return;

				}

				System.out.println("forwarding request to server");

				Socket bstoserv = new Socket(BootStrap.servername, BootStrap.serverport);

				if (bstoserv.isConnected()) {

					PrintWriter bsout = new PrintWriter(bstoserv.getOutputStream(), true);

					bsout.println(BootStrap.hashvalue);
					bsout.println(BootStrap.clientname);
					bsout.println(BootStrap.clientport);
					bsout.println(BootStrap.isFileRequest);
					bsout.println(BootStrap.isFileInsert);
					bsout.println(BootStrap.isNodeJoin);
					bsout.println(BootStrap.isNodeLeave);
					bsout.println("false");
					bsout.println(BootStrap.newSuccessor);
					bsout.println(BootStrap.newPredecessor);
					bsout.flush();
					bsout.close();

				}

				bstoserv.close();

			}

			/*
			 * illegal hash, do not forward request
			 */
			else {

				System.out.println("Incorrect hash value");
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
