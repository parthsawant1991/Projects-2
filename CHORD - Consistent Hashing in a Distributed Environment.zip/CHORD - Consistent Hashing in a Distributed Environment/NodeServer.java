import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.Iterator;

public class NodeServer {

	static HashMap<Integer, Integer> filedir = new HashMap<Integer, Integer>();

	static String servername = "localhost";
	static int serverport = 36678;
	static int hashrange = 1000;
	static int hashbegin = 0;
	static int hashend = 1000;
	static String successor = "localhost";
	static int successorport = 36678;
	static String predecessor = "localhost";
	static int predecessorport;

	static int hashvalue = 0;
	static String clientname;
	static int clientport;

	static boolean isFileRequest;
	static boolean isFileInsert;

	static boolean isNodeJoin;
	static boolean isNodeLeave;
	static boolean isSet;

	static String newSuccessor;
	static String newPredecessor;

	@SuppressWarnings("resource")
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		if (args.length > 0) {
			NodeServer.servername = args[0];
			NodeServer.serverport = Integer.parseInt(args[1]);
			NodeServer.hashvalue = Integer.parseInt(args[2]);

		}

		// initial join mechanism inside loop

		// start listener thread

		ServerSocket nodesocket = null;
		nodesocket = new ServerSocket(serverport);
		while (true) {

			Socket sock = null;
			sock = nodesocket.accept();

			new Thread(new NodeListener(sock)).start();

		}

	}

}

class NodeListener implements Runnable {

	Socket listensocket;

	public NodeListener(Socket sock) {
		// TODO Auto-generated constructor stub
		this.listensocket = sock;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub

		try {
			BufferedReader br = new BufferedReader(new InputStreamReader(listensocket.getInputStream()));

			NodeServer.hashvalue = Integer.parseInt(br.readLine());
			NodeServer.clientname = br.readLine();
			NodeServer.clientport = Integer.parseInt(br.readLine());

			NodeServer.isFileRequest = Boolean.parseBoolean(br.readLine());
			NodeServer.isFileInsert = Boolean.parseBoolean(br.readLine());

			NodeServer.isNodeJoin = Boolean.parseBoolean(br.readLine());
			NodeServer.isNodeLeave = Boolean.parseBoolean(br.readLine());
			NodeServer.isSet = Boolean.parseBoolean(br.readLine());

			NodeServer.newSuccessor = br.readLine();
			NodeServer.newPredecessor = br.readLine();

			int temp = 0;

			String tempsuccessorname = null;
			int tempsuccessorport = 0;

			tempsuccessorname = NodeServer.successor;
			tempsuccessorport = NodeServer.successorport;

			if (NodeServer.isNodeJoin) {

				System.out.println("node join");

				if (NodeServer.hashvalue >= NodeServer.hashbegin && NodeServer.hashvalue <= NodeServer.hashend) {

					NodeServer.hashend = NodeServer.hashvalue - 1;

					NodeServer.isSet = true;

					System.out.println("new hash range " + NodeServer.hashbegin + " " + NodeServer.hashend);

					tempsuccessorname = NodeServer.successor;
					tempsuccessorport = NodeServer.successorport;

					NodeServer.successor = NodeServer.clientname;
					NodeServer.successorport = NodeServer.clientport;

					// temp = NodeServer.clientport;

				}

				Socket s = new Socket("localhost", 9876);
				if (s.isConnected()) {

					PrintWriter clientout = new PrintWriter(s.getOutputStream(), true);

					clientout.println(NodeServer.hashvalue);
					clientout.println(NodeServer.servername);
					clientout.println(NodeServer.serverport);
					clientout.println(NodeServer.isFileRequest);
					clientout.println(NodeServer.isFileInsert);
					clientout.println(NodeServer.isNodeJoin);
					clientout.println(NodeServer.isNodeLeave);
					clientout.println(NodeServer.isSet);
					clientout.println(tempsuccessorname);
					clientout.println(tempsuccessorport);
					clientout.println(NodeServer.serverport);

					if (NodeServer.isSet) {

						Iterator it = NodeServer.filedir.entrySet().iterator();
						while (it.hasNext()) {
							HashMap.Entry pair = (HashMap.Entry) it.next();
							// System.out.println(pair);
							Integer k = (Integer) pair.getKey();
							// System.out.println(k);
							// System.out.println(NodeServer.hashend);

							if (k > NodeServer.hashend) {
								clientout.println(k);
								System.out.println(pair + " rehash");
							}
							it.remove(); // avoids a
											// ConcurrentModificationException
						}

					}

					clientout.flush();
					clientout.close();
					NodeServer.isSet = false;

				}

				System.out.println("new succcessor: " + NodeServer.successorport);

				s.close();

				return;

			}

			Thread.sleep(4000);

			/*
			 * if its a hash hit
			 */
			if (NodeServer.hashvalue >= NodeServer.hashbegin && NodeServer.hashvalue <= (NodeServer.hashend)) {

				System.out.println("Server Hit");

				/*
				 * node removal request
				 */

				if (NodeServer.isFileRequest) {

					if (NodeServer.filedir.containsKey(NodeServer.hashvalue)) {
						System.out.println("file request");
					} else {
						System.out.println("file not found");
					}

				}

				else if (NodeServer.isFileInsert) {

					System.out.println("file insert");
					NodeServer.filedir.put(NodeServer.hashvalue, NodeServer.hashvalue);

				}

				else if (NodeServer.isNodeLeave && NodeServer.hashvalue == NodeServer.hashbegin) {

					System.out.println("removal of server");

				}

				else {

					System.out.println("incorrect message");
				}

			}
			/*
			 * if its a hash miss forward request to successor
			 */
			else {

				System.out.println("forward request to sucessor: " + NodeServer.successor);

				Socket servtosucc = new Socket(NodeServer.successor, NodeServer.successorport);

				if (servtosucc.isConnected()) {

					PrintWriter servout = new PrintWriter(servtosucc.getOutputStream(), true);

					servout.println(NodeServer.hashvalue);
					servout.println(NodeServer.clientname);
					servout.println(NodeServer.clientport);
					servout.println(NodeServer.isFileRequest);
					servout.println(NodeServer.isFileInsert);
					servout.println(NodeServer.isNodeJoin);
					servout.println(NodeServer.isNodeLeave);
					servout.println(NodeServer.newSuccessor);
					servout.println(NodeServer.newPredecessor);
					servout.flush();
					servout.close();

				}

				System.out.println("closing socket");

				servtosucc.close();

			}

		} catch (IOException | InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}