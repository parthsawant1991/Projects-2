import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Client {

	static String bootstrapname;
	static int bootstrapport;

	static int hashvalue;
	static String clientname;
	static int clientport;

	static boolean isFileRequest;
	static boolean isFileInsert;

	static boolean isNodeJoin;
	static boolean isNodeLeave;

	static String newSuccessor;
	static String newPredecessor;

	public static void main(String[] args) throws UnknownHostException, IOException {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);

		System.out.println("enter 1 for file, 2 for node");

		int choice = sc.nextInt();

		/*
		 * file insertion and retrieval
		 */
		if (choice == 1) {

			System.out.println("enter 1 for insert, 2 for retrieval");

			int choice2 = sc.nextInt();

			/*
			 * file insertion request
			 */
			if (choice2 == 1) {

				System.out.println("enter file hash");
				hashvalue = sc.nextInt();

				Socket clienttobs = new Socket("localhost", 36465);

				clientname = clienttobs.getLocalAddress().getHostName();
				clientport = clienttobs.getLocalPort();
				isFileRequest = false;
				isFileInsert = true;
				isNodeJoin = false;
				isNodeLeave = false;
				newSuccessor = "";
				newPredecessor = "";

				if (clienttobs.isConnected()) {

					PrintWriter clientout = new PrintWriter(clienttobs.getOutputStream(), true);

					clientout.println(hashvalue);
					clientout.println(clientname);
					clientout.println(clientport);
					clientout.println(isFileRequest);
					clientout.println(isFileInsert);
					clientout.println(isNodeJoin);
					clientout.println(isNodeLeave);
					clientout.println(newSuccessor);
					clientout.println(newPredecessor);
					clientout.flush();
					clientout.close();

				}
				clienttobs.close();

			}
			/*
			 * file retrieval request
			 */
			else if (choice2 == 2) {

				System.out.println("enter file hash");
				hashvalue = sc.nextInt();

				Socket clienttobs = new Socket("localhost", 36465);

				clientname = clienttobs.getLocalAddress().getHostName();
				clientport = clienttobs.getLocalPort();
				isFileRequest = true;
				isFileInsert = false;
				isNodeJoin = false;
				isNodeLeave = false;
				newSuccessor = "";
				newPredecessor = "";

				if (clienttobs.isConnected()) {

					PrintWriter clientout = new PrintWriter(clienttobs.getOutputStream(), true);

					clientout.println(hashvalue);
					clientout.println(clientname);
					clientout.println(clientport);
					clientout.println(isFileRequest);
					clientout.println(isFileInsert);
					clientout.println(isNodeJoin);
					clientout.println(isNodeLeave);
					clientout.println(newSuccessor);
					clientout.println(newPredecessor);
					clientout.flush();
					clientout.close();

				}
				clienttobs.close();

			} else {
				System.out.println("enter valid choice");
			}

		}
		/*
		 * node removal
		 */
		else if (choice == 2) {

			System.out.println("enter 1 for node removal");
			int choice3 = sc.nextInt();

			if (choice3 == 1) {

				System.out.println("enter hash of server to be removed");
				hashvalue = sc.nextInt();

				Socket clienttobs = new Socket("localhost", 36465);

				clientname = clienttobs.getLocalAddress().getHostName();
				clientport = clienttobs.getLocalPort();
				isFileRequest = true;
				isFileInsert = false;
				isNodeJoin = false;
				isNodeLeave = true;
				newSuccessor = "";
				newPredecessor = "";

				if (clienttobs.isConnected()) {

					PrintWriter clientout = new PrintWriter(clienttobs.getOutputStream(), true);

					clientout.println(hashvalue);
					clientout.println(clientname);
					clientout.println(clientport);
					clientout.println(isFileRequest);
					clientout.println(isFileInsert);
					clientout.println(isNodeJoin);
					clientout.println(isNodeLeave);
					clientout.println("false");
					clientout.println(newSuccessor);
					clientout.println(newPredecessor);
					clientout.flush();
					clientout.close();

				}
				clienttobs.close();

			}

		} else {
			System.out.println("enter valid choice");
		}

	}

}
