import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;

public class NodeServer3 {

	static HashMap<Integer, Integer> filedir = new HashMap<Integer, Integer>();

	static String servername = "localhost";
	static int serverport = 12545;
	static int hashrange = 500;
	static int hashbegin = 500;
	static int hashend = 1000;
	static String successor = "localhost";
	static int successorport = 36465;
	static String predecessor = "localhost";
	static int pedecessorport = 0;

	static int hashvalue = 300;
	static String clientname;
	static int clientport;
	static boolean isSet = false;

	static boolean isFileRequest;
	static boolean isFileInsert;

	static boolean isNodeJoin;
	static boolean isNodeLeave;

	static String newSuccessor;
	static String newPredecessor;

	@SuppressWarnings("resource")
	public static void main(String[] args) throws IOException, InterruptedException {
		// TODO Auto-generated method stub

		if (args.length > 0) {
			NodeServer3.servername = args[0];
			NodeServer3.serverport = Integer.parseInt(args[1]);
			NodeServer3.hashbegin = Integer.parseInt(args[2]);

		}

		// initial join mechanism inside loop

		while (!isSet) {

			// send request
			Thread.sleep(2000);

			System.out.println("requesting id space");
			Socket servtoserv = new Socket(NodeServer3.successor, NodeServer3.successorport);

			clientname = servtoserv.getLocalAddress().getHostName();
			clientport = servtoserv.getLocalPort();
			isFileRequest = false;
			isFileInsert = false;
			isNodeJoin = true;
			isNodeLeave = false;
			newSuccessor = "";
			newPredecessor = "";

			if (servtoserv.isConnected()) {

				System.out.println("connected to: " + servtoserv.getInetAddress().getHostName());
				PrintWriter clientout = new PrintWriter(servtoserv.getOutputStream(), true);
				// BufferedReader br = new BufferedReader(new
				// InputStreamReader(servtoserv.getInputStream()));

				clientout.println(hashbegin);
				clientout.println(servername);
				clientout.println(serverport);
				clientout.println(isFileRequest);
				clientout.println(isFileInsert);
				clientout.println(isNodeJoin);
				clientout.println(isNodeLeave);
				clientout.println("false");
				clientout.println(newSuccessor);
				clientout.println(newPredecessor);
				clientout.flush();
				clientout.close();

				ServerSocket serv = new ServerSocket(9876);
				Socket soc = serv.accept();

				BufferedReader br = new BufferedReader(new InputStreamReader(soc.getInputStream()));
				System.out.println("reply");

				NodeServer3.hashvalue = Integer.parseInt(br.readLine());
				NodeServer3.clientname = br.readLine();
				NodeServer3.clientport = Integer.parseInt(br.readLine());

				NodeServer3.isFileRequest = Boolean.parseBoolean(br.readLine());
				NodeServer3.isFileInsert = Boolean.parseBoolean(br.readLine());

				NodeServer3.isNodeJoin = Boolean.parseBoolean(br.readLine());
				NodeServer3.isNodeLeave = Boolean.parseBoolean(br.readLine());
				NodeServer3.isSet = Boolean.parseBoolean(br.readLine());

				NodeServer3.successor = br.readLine();
				NodeServer3.successorport = Integer.parseInt(br.readLine());

				NodeServer3.newPredecessor = br.readLine();
				soc.close();
				serv.close();

				/*
				 * ID space found
				 */
				if (isSet) {

					System.out.println("id space found");

					// successorport = NodeServer3.successorport;
					predecessor = NodeServer3.clientname;
					pedecessorport = NodeServer3.clientport;
					System.out.println("new successor: " + successorport);

					System.out.println("new predecessor:" + pedecessorport);

					System.out.println("update current ID space");

					System.out.println("notify soccessor to change successor");

					//

				}
				/*
				 * ID space not found, forward request to next server
				 */
				else {

					System.out.println("id space not found, forwarding request to next server");

					// successorport = NodeServer3.successorport;
					predecessor = NodeServer3.newPredecessor;
					System.out.println("new successor: " + successorport);

				}

			}

			servtoserv.close();

		}

		// start listener thread

		ServerSocket nodesocket = null;
		nodesocket = new ServerSocket(serverport);
		while (true) {

			Socket sock = null;
			sock = nodesocket.accept();

			new Thread(new NodeListener3(sock)).start();

		}

	}

}

class NodeListener3 implements Runnable {

	Socket listensocket;

	public NodeListener3(Socket sock) {
		// TODO Auto-generated constructor stub
		this.listensocket = sock;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub

		try {
			BufferedReader br = new BufferedReader(new InputStreamReader(listensocket.getInputStream()));

			NodeServer3.hashvalue = Integer.parseInt(br.readLine());
			NodeServer3.clientname = br.readLine();
			NodeServer3.clientport = Integer.parseInt(br.readLine());

			NodeServer3.isFileRequest = Boolean.parseBoolean(br.readLine());
			NodeServer3.isFileInsert = Boolean.parseBoolean(br.readLine());

			NodeServer3.isNodeJoin = Boolean.parseBoolean(br.readLine());
			NodeServer3.isNodeLeave = Boolean.parseBoolean(br.readLine());
			NodeServer3.isSet = Boolean.parseBoolean(br.readLine());

			NodeServer3.newSuccessor = br.readLine();
			NodeServer3.newPredecessor = br.readLine();

			if (NodeServer3.newPredecessor != "") {

				NodeServer2.predecessorport = Integer.parseInt(NodeServer2.newPredecessor);
				System.out.println("predecessor updeated to: " + NodeServer2.predecessorport);

				return;
				
			}

			if (NodeServer3.hashvalue >= NodeServer3.hashbegin && NodeServer3.hashvalue <= (NodeServer3.hashend)) {

				System.out.println("Server Hit");

				/*
				 * node removal request
				 */
				if (NodeServer.isNodeLeave && NodeServer.hashvalue == NodeServer.hashbegin) {

					System.out.println("removal of server");

				}

				if (NodeServer3.isFileRequest) {

					if (NodeServer3.filedir.containsKey(NodeServer3.hashvalue)) {
						System.out.println("file request");
					} else {
						System.out.println("file not found");
					}

				} else if (NodeServer3.isFileInsert) {

					System.out.println("file insert");
					NodeServer3.filedir.put(NodeServer3.hashvalue, NodeServer3.hashvalue);

				} else if (NodeServer3.isNodeJoin) {

					System.out.println("node join");

				} else if (NodeServer3.isNodeLeave) {

					System.out.println("node leave");

				} else {

					System.out.println("incorrect message");
				}

			} else {

				System.out.println("forward request to successor: " + NodeServer3.successor);

				Socket servtosucc = new Socket(NodeServer3.successor, NodeServer3.successorport);

				if (servtosucc.isConnected()) {

					PrintWriter servout = new PrintWriter(servtosucc.getOutputStream(), true);

					servout.println(NodeServer3.hashvalue);
					servout.println(NodeServer3.clientname);
					servout.println(NodeServer3.clientport);
					servout.println(NodeServer3.isFileRequest);
					servout.println(NodeServer3.isFileInsert);
					servout.println(NodeServer3.isNodeJoin);
					servout.println(NodeServer3.isNodeLeave);
					servout.println("false");
					servout.println(NodeServer3.newSuccessor);
					servout.println("");
					servout.flush();
					servout.close();

				}

				servtosucc.close();

			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}